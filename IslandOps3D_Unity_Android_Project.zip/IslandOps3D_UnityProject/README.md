# ISLAND OPS 3D — Unity Android Starter Project

Ini adalah **project sumber Unity**, bukan APK yang sudah dikompilasi. Project membuat arena 3D sederhana saat runtime: pulau, pepohonan, rumah, karakter pemain, dan 8 bot pengejar.

## Versi yang disarankan
- Unity 2022.3 LTS atau Unity 6
- Template 3D (Built-in Render Pipeline)
- Android Build Support + Android SDK/NDK + OpenJDK melalui Unity Hub

## Cara membuka
1. Ekstrak ZIP.
2. Unity Hub → Add → pilih folder `IslandOps3D_UnityProject`.
3. Buka project dan tunggu import.
4. Dari menu Unity pilih **Island Ops → Create Demo Scene**. Scene `Assets/Scenes/Main.unity` akan dibuat otomatis.
5. Tekan Play untuk tes di Editor.

## Build APK Android
1. File → Build Settings (atau Build Profiles di Unity 6).
2. Pilih Android → Switch Platform.
3. Player Settings: set Package Name `com.islandops.battleroyale`.
4. Set Orientation ke Landscape.
5. Tambahkan scene `Main` ke Scenes In Build.
6. Build → pilih lokasi output `.apk`.

## Kontrol
- PC: WASD / tombol panah untuk bergerak; klik kiri untuk menembak; drag mouse untuk kamera.
- Android: tombol HUD di layar untuk bergerak/menembak; geser sisi kanan layar untuk kamera.

## Catatan
Ini fondasi prototype yang dapat dibuka dan dikembangkan di Unity. Belum termasuk aset karakter profesional, animasi rigged, kendaraan, parasut, multiplayer, audio, optimasi map besar, atau sistem matchmaking. Build APK harus dilakukan melalui Unity Editor dengan Android Build Support terpasang.
